package com.example.examplemod;

import com.example.examplemod.UI;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

// GUI STUFF
public class ini_UI extends CommandBase {

    @Override
    public String getCommandName() {
        return "mui";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/mui";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        
        if (sender instanceof net.minecraft.client.entity.EntityPlayerSP) {
            main.is_gui = true;
        }


    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0; // allows any player to run it
    }
}
