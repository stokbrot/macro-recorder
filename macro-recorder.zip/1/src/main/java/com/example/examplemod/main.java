package com.example.examplemod;

import com.example.examplemod.ini_UI;
import com.example.examplemod.UI;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import java.time.LocalTime;


import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.io.BufferedWriter;
import java.io.File;
import java.util.Scanner;


// .\gradlew runClient
// .\gradlew build
// ./gradlew clean build


/*

## How to Compile Your Minecraft Mod for Release

1. **Open a terminal** in your project folder (where `build.gradle` is located).

2. **Run the build command:**
   - On Windows:
     ```
     .\gradlew build
     ```
   - On Linux/macOS:
     ```
     ./gradlew build
     ```

3. **Find your compiled mod JAR** in:
   ```
   build/libs/
   ```
   The file will look like:
   ```
   yourmodid-version.jar
   ```

4. **To use or share your mod:**
   - Copy the JAR from `build/libs/` to the `mods` folder of any Forge 1.8.9 Minecraft installation.

> You do **not** need to include the `run` or `build` folders when sharing your mod—just the JAR in `build/libs/`.

 */


@Mod(modid = "stokbrot", name = "Stokbrot is King", version = "69.420")
public class main {

    public static List<PlayerState> recordedStates = new ArrayList<>();

    public static boolean is_gui = false;

    private boolean isRecording = false; // Tracks whether recording is active
    private boolean isPlaying = false; // Tracks whether recording is active
    private int index = 0; // Keeps track of the current view angle

    private KeyBinding recordKey; // Keybinding for starting/stopping recording
    private KeyBinding playKey; // Keybinding for starting/stopping recording

    private final Minecraft mc = Minecraft.getMinecraft();

    private static boolean toggled = false;
    private double failsafe_trigger_distance = 1.0;

    private int smoothTicks = 0;
    private float startYaw, startPitch, endYaw, endPitch;
    private float[] yawNoise = new float[20];
    private float[] pitchNoise = new float[20];
    private boolean smoothing = false;

    private long playStartTime = 0;
    private float startYawNoise, endYawNoise, startPitchNoise, endPitchNoise;
    private int smoothingTicksTotal = 5; // Total ticks for smoothing

    private float noiseFactor = 5.0f; // Change this to control randomness

    public static class PlayerState {
        public double posX, posY, posZ;
        public float yaw, pitch;
        public boolean forward, left, right, backward, jump, sprint, sneak, attack, use;

        public PlayerState(double posX, double posY, double posZ,
                           float yaw, float pitch, 
                           boolean forward, boolean left, boolean right, boolean backward, 
                           boolean jump, boolean sprint, boolean sneak,
                           boolean attack, boolean use) {
            this.posX = posX;
            this.posY = posY;
            this.posZ = posZ;
            this.yaw = yaw;
            this.pitch = pitch;
            this.forward = forward;
            this.left = left;
            this.right = right;
            this.backward = backward;
            this.jump = jump;
            this.sprint = sprint;
            this.sneak = sneak;
            this.attack = attack;
            this.use = use;           
        }
    }


    public static void disconnect() {
        Minecraft mc = Minecraft.getMinecraft();
        
        if (mc.theWorld != null) {
            mc.theWorld.sendQuittingDisconnectingPacket(); // Send proper quit packet
            mc.loadWorld((WorldClient) null); // Unload the world
            mc.displayGuiScreen(new GuiMainMenu()); // Go to main menu
        }
    }

    private void unpressAllKeys() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
    }

    // Main.mc.gameSettings.keyBindLeft.getKeyCode(), left
    public static void writePlayerStatesToFile(String filePath) {
        File file = new File(filePath);
    
        // Check if the file exists, create it if it doesn't
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("File created: " + file.getAbsolutePath());
                }
            } catch (IOException e) {
                System.err.println("Error creating file: " + e.getMessage());
                return; // Stop execution if file creation fails
            }
        }
    
        // Now write to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) { // Overwrite file
            for (PlayerState state : recordedStates) {
                // Format: posX,posY,posZ,yaw,pitch,forward,left,right,backward,jump,sprint,sneak,attack,use
                writer.write(String.format("%.6f,%.6f,%.6f,%.2f,%.2f,%b,%b,%b,%b,%b,%b,%b,%b,%b%n",
                        state.posX, state.posY, state.posZ,
                        state.yaw, state.pitch,
                        state.forward, state.left, state.right, state.backward,
                        state.jump, state.sprint, state.sneak,
                        state.attack, state.use));
            }
            System.out.println("File written successfully.");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }


    }
    

    public static void loadPlayerStatesFromFile(String filePath) {
        recordedStates.clear(); // Clear existing data before loading
    
        File file = new File(filePath);
    
        // Check if the file exists, create it if it doesn't
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("File created: " + file.getAbsolutePath());
                }
            } catch (IOException e) {
                System.err.println("Error creating file: " + e.getMessage());
                return; // Stop execution if file creation fails
            }
        }
    
        // Now read the file
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(","); // Split by comma
                
                
                if (parts.length == 14) {
                    try {
                        // Parse position and angles
                        double x = Double.parseDouble(parts[0]);
                        double y = Double.parseDouble(parts[1]);
                        double z = Double.parseDouble(parts[2]);
                        float yaw = Float.parseFloat(parts[3]);
                        float pitch = Float.parseFloat(parts[4]);
                
                        // Parse movement input and states
                        boolean forward = Boolean.parseBoolean(parts[5]);
                        boolean left = Boolean.parseBoolean(parts[6]);
                        boolean right = Boolean.parseBoolean(parts[7]);
                        boolean backward = Boolean.parseBoolean(parts[8]);
                        boolean jump = Boolean.parseBoolean(parts[9]);
                        boolean sprint = Boolean.parseBoolean(parts[10]);
                        boolean sneak = Boolean.parseBoolean(parts[11]);
                        boolean attack = Boolean.parseBoolean(parts[12]);
                        boolean use = Boolean.parseBoolean(parts[13]);
                
                        // Add the state with all data (position, angles, movement, mouse)
                        recordedStates.add(new PlayerState(x, y, z, yaw, pitch, forward, left, right, backward, jump, sprint, sneak, attack, use));
                    } 
                    catch (NumberFormatException e) {
                        System.err.println("Error parsing numbers in line: " + line);
                    }
                } 
                else {
                    System.err.println("Invalid line format: " + line); // Incorrect number of values
                }
            }
            System.out.println("File loaded successfully.");
        } 
        catch (IOException e){
            System.err.println("Error reading from file: " + e.getMessage());
        }
    }
    

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Register the keybinding (B key)
        recordKey = new KeyBinding("Start/Stop Recording", Keyboard.KEY_B, "!");
        playKey = new KeyBinding("Play Recording", Keyboard.KEY_P, "!");

        ClientRegistry.registerKeyBinding(recordKey);
        ClientRegistry.registerKeyBinding(playKey);


        // Register UI Class
        ClientCommandHandler.instance.registerCommand(new ini_UI());
        System.out.println("[OpenUi] Registering command");

        // Register the event handler
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyPress(InputEvent.KeyInputEvent event) {
        // Check if the record key (B) is pressed

        if (playKey.isPressed()){          
            index = 0;

            if (recordedStates.isEmpty()) {
                mc.thePlayer.addChatMessage(new ChatComponentText("No recorded states found."));
                mc.thePlayer.addChatMessage(new ChatComponentText("Load one first! Or record one!"));
            } 
            else {
                boolean wasPlaying = isPlaying;
                isPlaying = !isPlaying;
                mc.thePlayer.addChatMessage(new ChatComponentText("Playing: " + (isPlaying ? "§aStarted" : "§cStopped")));

                if (isPlaying && !wasPlaying) {
                    playStartTime = System.currentTimeMillis(); // Start time
                }
                if (!isPlaying && wasPlaying) {
                    long playEndTime = System.currentTimeMillis();
                    long duration = playEndTime - playStartTime;
                    long minutes = (duration / 1000) / 60;
                    long seconds = (duration / 1000) % 60;
                    mc.thePlayer.addChatMessage(new ChatComponentText(
                        String.format("§r§0-- RAN FOR §b%d§0m §b%d§0s --", minutes, seconds)
                    ));
                }

                if(!isPlaying){
                    unpressAllKeys();
                }
            }
        }

        if (recordKey.isPressed()) {
            // Toggle recording           
            if(isRecording){
                isRecording = false;            
                //writePlayerStatesToFile("mods/script.txt");
            }

            else{
                recordedStates.clear();
                isRecording = true;}

             
            mc.thePlayer.addChatMessage(new ChatComponentText("Recording: " + (isRecording ? "§aStarted" : "§cStopped")));
            System.out.println("Recording: " + (isRecording ? "Started" : "Stopped"));
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {

        if (is_gui) {
            net.minecraft.client.Minecraft.getMinecraft().displayGuiScreen(new UI());
            is_gui = false;
        }

        // Check if it's the end of a tick (to avoid running twice per tick)
        if (event.phase == TickEvent.Phase.END) {

            // Check if player is valid
            EntityPlayerSP player = mc.thePlayer;
            if (player != null) {

                if(isPlaying && !isRecording){
                    if (index < recordedStates.size()) { // check if in index range to proceed

                        
                        PlayerState state = recordedStates.get(index);
                        
                            

                        double x = state.posX;
                        double y = state.posY;
                        double z = state.posZ;
                        double dx = player.posX;
                        double dy = player.posY;
                        double dz = player.posZ;



                        

                        //player.posY = state.posY;
                        //player.posZ = state.posZ;
                        
                        




                        player.rotationYaw = state.yaw;  // Set yaw (horizontal)
                        player.rotationPitch = state.pitch; // Set pitch (vertical)
                        
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), state.forward);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), state.left);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), state.right);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), state.backward);

                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), state.jump);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), state.sprint);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), state.sneak);

                        
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), state.attack);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), state.use);
                            
                        
        

                        // Wenn nur um ein block falsch dann quit
                        // Muss hier sein sonst pressed das ja noch die keys von der letzten state
                        if (Math.abs(x - dx) >= failsafe_trigger_distance || 
                            Math.abs(y - dy) >= failsafe_trigger_distance || 
                            Math.abs(z - dz) >= failsafe_trigger_distance) 
                        {
                            // send dc message maybe
                            player.addChatMessage(new ChatComponentText("Failsafe Triggered at: " + LocalTime.now()));//  "Current Pos: " + x + " " + y + " " + z + "Should: " + dx + " " + dy + " " + dz
                            
                            //Thread.sleep(3000);

                            unpressAllKeys();

                            //player.addChatMessage(new ChatComponentText("? nah"));

                            isRecording = false;
                            isPlaying = false;
                            //disconnect();
                        }

                        index++; // Move to the next view angle


                    }
                    else{index = 0;}
                }


                if(isRecording && !isPlaying){
                     

                    
                    // Store Playerstate
                    recordedStates.add(new PlayerState(

                        player.posX,
                        player.posY,
                        player.posZ,

                        player.rotationYaw,
                        player.rotationPitch,

                        mc.gameSettings.keyBindForward.isKeyDown(),  // W
                        mc.gameSettings.keyBindLeft.isKeyDown(),     // A
                        mc.gameSettings.keyBindRight.isKeyDown(),    // D
                        mc.gameSettings.keyBindBack.isKeyDown(),     // S

                        mc.gameSettings.keyBindJump.isKeyDown(),     // Space (Jump)
                        player.isSprinting(),                  // Sprint
                        player.isSneaking(),                    // Sneak (Shift)

                        mc.gameSettings.keyBindAttack.isKeyDown(),
                        mc.gameSettings.keyBindUseItem.isKeyDown()


                    ));                                                                                                                   
                }
            }
        }

        if (UI.rdmChecked && isPlaying && index >= recordedStates.size() && recordedStates.size() > 1) {
            unpressAllKeys(); // Unpress all keys before smoothing
            // Prepare smoothing from last to first
            PlayerState last = recordedStates.get(recordedStates.size() - 1);
            PlayerState first = recordedStates.get(0);
            startYaw = last.yaw;
            startPitch = last.pitch;
            endYaw = first.yaw;
            endPitch = first.pitch;

            // Smoothing setup (when starting smoothing)
            startYawNoise = (float)((Math.random() - 0.5) * 2 * noiseFactor);
            endYawNoise = (float)((Math.random() - 0.5) * 2 * noiseFactor);
            startPitchNoise = (float)((Math.random() - 0.5) * 1 * noiseFactor);
            endPitchNoise = (float)((Math.random() - 0.5) * 1 * noiseFactor);

            smoothTicks = 0;
            smoothing = true;
            
            isPlaying = false; // Stop normal playback
        }

        if (smoothing && UI.rdmChecked && mc.thePlayer != null) {
            if (smoothTicks < smoothingTicksTotal) {
                float t = (float)smoothTicks / (smoothingTicksTotal - 1);
                float noiseYaw = startYawNoise + (endYawNoise - startYawNoise) * t;
                float noisePitch = startPitchNoise + (endPitchNoise - startPitchNoise) * t;
                float yaw = startYaw + (endYaw - startYaw) * t + noiseYaw;
                float pitch = startPitch + (endPitch - startPitch) * t + noisePitch;
                mc.thePlayer.rotationYaw = yaw;
                mc.thePlayer.rotationPitch = pitch;
                smoothTicks++;
            } else {
                smoothing = false;
                mc.thePlayer.rotationYaw = endYaw;
                mc.thePlayer.rotationPitch = endPitch;
                index = 0;
                isPlaying = true;
            }
        }
    }
}