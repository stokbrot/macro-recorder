package com.example.examplemod;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ChatComponentText;
import org.lwjgl.input.Keyboard;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UI extends GuiScreen {

    private static final String MACRO_EXT = ".macro";
    private File macroDir = new File("macros");
    private List<String> macroNames = new ArrayList<>();
    private GuiTextField saveNameField;
    private GuiTextField macroNameField;
    private String statusMessage = "";
    private int scrollOffset = 0;
    private static final int VISIBLE_MACROS = 6;

    private static int macroListY = 90; // Starting Y position for macro list

    public static boolean rdmChecked = false;

    private String getRdmCheckboxLabel() {
        return (rdmChecked ? "[X] " : "[ ] ") + "rdm";
    }

    @Override
    public void initGui() {
        this.buttonList.clear();
        if (!macroDir.exists()) macroDir.mkdirs();

        // List macro files
        macroNames.clear();
        File[] files = macroDir.listFiles((dir, name) -> name.endsWith(MACRO_EXT));
        if (files != null) {
            for (File f : files) {
                String name = f.getName();
                if (name.endsWith(MACRO_EXT)) name = name.substring(0, name.length() - MACRO_EXT.length());
                macroNames.add(name);
            }
        }

        // Save field and button at the top, under the title
        int saveY = 40;
        this.saveNameField = new GuiTextField(0, this.fontRendererObj, this.width / 2 - 50, saveY, 100, 20);
        this.saveNameField.setMaxStringLength(50);
        this.buttonList.add(new GuiButton(0, this.width / 2 + 55, saveY, 50, 20, "Save"));

        // Macro list below save row
        int y = saveY + 50;
        int max = Math.min(VISIBLE_MACROS, macroNames.size() - scrollOffset);
        for (int i = 0; i < max; i++) {
            int rowY = y + i * 24;
            this.buttonList.add(new GuiButton(100 + i * 2, this.width / 2 - 50, rowY, 50, 20, "Load"));
            this.buttonList.add(new GuiButton(101 + i * 2, this.width / 2 + 5, rowY, 50, 20, "Delete"));
        }

        // Checkbox on the far left
        this.buttonList.add(new GuiButton(5000, 20, saveY, 60, 20, getRdmCheckboxLabel()));

        Keyboard.enableRepeatEvents(true);
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 2000 && scrollOffset > 0) { // Up
            scrollOffset--;
            this.initGui();
            return;
        }
        if (button.id == 2001 && scrollOffset + VISIBLE_MACROS < macroNames.size()) { // Down
            scrollOffset++;
            this.initGui();
            return;
        }
        int y = this.height / 2 - 40;
        int macroIndex = (button.id - 100) / 2;
        if (button.id == 0) { // Save new macro
            String name = saveNameField.getText().trim();
            if (!name.isEmpty()) {
                String fileName = name.endsWith(MACRO_EXT) ? name : name + MACRO_EXT;
                main.writePlayerStatesToFile(new File(macroDir, fileName).getPath());
                statusMessage = "Saved as " + name;
                this.initGui(); // Refresh list
            }
        } else if (button.id >= 100 && button.id % 2 == 0) { // Load
            if (macroIndex >= 0 && macroIndex < macroNames.size()) {
                String fileName = macroNames.get(macroIndex) + MACRO_EXT;
                main.loadPlayerStatesFromFile(new File(macroDir, fileName).getPath());
                statusMessage = "Loaded " + macroNames.get(macroIndex);
            }
        } else if (button.id >= 101 && button.id % 2 == 1) { // Delete
            if (macroIndex >= 0 && macroIndex < macroNames.size()) {
                String fileName = macroNames.get(macroIndex) + MACRO_EXT;
                File f = new File(macroDir, fileName);
                if (f.exists()) f.delete();
                statusMessage = "Deleted " + macroNames.get(macroIndex);
                this.initGui(); // Refresh list
            }
        } 
        if (button.id == 5000) {
            rdmChecked = !rdmChecked;
            button.displayString = getRdmCheckboxLabel();
            System.out.println("Pressed rdm checkbox: " + rdmChecked);


        }
        System.out.println("Button pressed: " + button.id);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, "Macro Recorder Menu", this.width / 2, 20, 0xFFFFFF);

        // Draw save field and button
        this.saveNameField.drawTextBox();

        // Draw status message just below the save field
        int statusY = this.saveNameField.yPosition + this.saveNameField.height + 4;
        this.drawCenteredString(this.fontRendererObj, statusMessage, this.width / 2, statusY, 0x00FF00);

        // Draw macro names

        int max = Math.min(VISIBLE_MACROS, macroNames.size() - scrollOffset);
        for (int i = 0; i < max; i++) {
            int macroIdx = i + scrollOffset;
            int rowY = macroListY + i * 24 + 6; // + 6 for vertical centering, adjust if needed
            if (macroIdx < macroNames.size()) {
                this.drawString(this.fontRendererObj, macroNames.get(macroIdx), this.width / 2 - 110, rowY, 0xAAAAAA);
            }
        }

        // Draw scroll indicator as a bar
        drawScrollBar(macroListY, max);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        super.keyTyped(typedChar, keyCode);
        this.saveNameField.textboxKeyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        this.saveNameField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int dWheel = org.lwjgl.input.Mouse.getDWheel();
        if (dWheel != 0) {
            if (dWheel > 0 && scrollOffset > 0) {
                scrollOffset--;
                this.initGui();
            } else if (dWheel < 0 && scrollOffset + VISIBLE_MACROS < macroNames.size()) {
                scrollOffset++;
                this.initGui();
            }
        }
    }

    private void drawScrollBar(int listY, int visible) {
        int total = macroNames.size();
        if (total <= VISIBLE_MACROS) return; // No need for a scrollbar

        int trackHeight = (24 * VISIBLE_MACROS) - 6;
        int barX = this.width / 2 + 60;

        // Calculate bar height (minimum 16px)
        int barHeight = Math.max(16, (int)((float)VISIBLE_MACROS / total * trackHeight));
        // Calculate bar position
        int maxScroll = total - VISIBLE_MACROS;
        int barY = listY;
        if (maxScroll > 0) {
            barY += (int)((float)scrollOffset / maxScroll * (trackHeight - barHeight));
        }

        // Draw track
        drawRect(barX, listY, barX + 4, listY + trackHeight, 0xFF444444);
        // Draw bar
        drawRect(barX, barY, barX + 4, barY + barHeight, 0xFFAAAAAA);
    }
}

