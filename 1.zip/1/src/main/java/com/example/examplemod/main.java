package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




@Mod(modid = "stokbrot", name = "Stokbrot is King", version = "69.420")
public class main {

    public class PlayerState {
        public double x, y, z;
        public float yaw, pitch;
    
        public PlayerState(double x, double y, double z, float yaw, float pitch) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    List<PlayerState> recordedStates = new ArrayList<>();

    private boolean isRecording = false; // Tracks whether recording is active
    private boolean isPlaying = false; // Tracks whether recording is active
    private int index = 0; // Keeps track of the current view angle

    private KeyBinding recordKey; // Keybinding for starting/stopping recording
    private KeyBinding playKey; // Keybinding for starting/stopping recording

    private final Minecraft mc = Minecraft.getMinecraft();
    
    

    // Main.mc.gameSettings.keyBindLeft.getKeyCode(), left
    public void writePlayerStatesToFile(String filePath) {
        try (FileWriter writer = new FileWriter(filePath, false)) { // Overwrite file
            for (PlayerState state : recordedStates) {
                // Format: x,y,z,yaw,pitch
                writer.write(state.x + "," + state.y + "," + state.z + "," + state.yaw + "," + state.pitch + "\n");
            }
            System.out.println("File written successfully.");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }
    

    public void loadPlayerStatesFromFile(String filePath) {
        recordedStates.clear(); // Clear existing data before loading
    
        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(","); // Split by comma
    
                if (parts.length == 5) { // Ensure correct format (x, y, z, yaw, pitch)
                    double x = Double.parseDouble(parts[0]);
                    double y = Double.parseDouble(parts[1]);
                    double z = Double.parseDouble(parts[2]);
                    float yaw = Float.parseFloat(parts[3]);
                    float pitch = Float.parseFloat(parts[4]);
    
                    recordedStates.add(new PlayerState(x, y, z, yaw, pitch));
                } else {
                    System.err.println("Invalid line format: " + line);
                }
            }
            System.out.println("File loaded successfully.");
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Error parsing numbers: " + e.getMessage());
        }
    }
    

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Register the keybinding (B key)
        recordKey = new KeyBinding("Start/Stop Recording", Keyboard.KEY_B, "!");
        playKey = new KeyBinding("Play Recording", Keyboard.KEY_P, "!");

        ClientRegistry.registerKeyBinding(recordKey);
        ClientRegistry.registerKeyBinding(playKey);

        // Register the event handler
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyPress(InputEvent.KeyInputEvent event) {
        // Check if the record key (B) is pressed

        if (playKey.isPressed()){          
            index = 0;
            recordedStates.clear();
            loadPlayerStatesFromFile("C:\\Users\\jakob\\Desktop\\mcmod\\1\\src\\main\\java\\com\\example\\examplemod\\script.txt");           
            isPlaying = !isPlaying;
            mc.thePlayer.addChatMessage(new ChatComponentText("Playing: " + (isPlaying ? "§aStarted" : "§cStopped")));
        }

        if (recordKey.isPressed()) {
            // Toggle recording           
            if(isRecording){
                isRecording = false;
                writePlayerStatesToFile("C:\\Users\\jakob\\Desktop\\mcmod\\1\\src\\main\\java\\com\\example\\examplemod\\script.txt");
            }

            else{
                recordedStates.clear();
                isRecording = true;}

             
            mc.thePlayer.addChatMessage(new ChatComponentText("Recording: " + (isRecording ? "§aStarted" : "§cStopped")));
            System.out.println("Recording: " + (isRecording ? "Started" : "Stopped"));
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {

        // Check if it's the end of a tick (to avoid running twice per tick)
        if (event.phase == TickEvent.Phase.END) {

            // Check if player is valid
            EntityPlayerSP player = mc.thePlayer;
            if (player != null) {

                if(isPlaying && !isRecording){
                    if (index < recordedStates.size()) { // check if in index range to proceed

                        
                        PlayerState state = recordedStates.get(index);
                        
                            

                        player.posX = state.x;
                        player.posY = state.y;
                        player.posZ = state.z;
                        player.rotationYaw = state.yaw;  // Set yaw (horizontal)
                        player.rotationPitch = state.pitch; // Set pitch (vertical)
                        
        
                        
        
        
        
                        index++; // Move to the next view angle
        
                        
                    }
                    else{index = 0;}
                }


                if(isRecording && !isPlaying){
                    
                    float yaw = player.rotationYaw;
                    float pitch = player.rotationPitch;

                    double x = player.posX;
                    double y = player.posY;
                    double z = player.posZ;

                    // Store the view angles in the array
                    recordedStates.add(new PlayerState(x, y, z, yaw, pitch));

                    
                    //System.out.println("Added angles");
                    
                    
                }
            }
        }
    }
}