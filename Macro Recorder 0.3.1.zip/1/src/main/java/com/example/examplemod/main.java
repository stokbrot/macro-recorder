package com.example.examplemod;

import com.example.examplemod.ini_UI;
import com.example.examplemod.UI;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import java.time.LocalTime;


import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.io.BufferedWriter;
import java.io.File;
import java.util.Scanner;


// .\gradlew runClient
// .\gradlew build
// ./gradlew clean build


/*

## How to Compile Your Minecraft Mod for Release

1. **Open a terminal** in your project folder (where `build.gradle` is located).

2. **Run the build command:**
   - On Windows:
     ```
     .\gradlew build
     ```
   - On Linux/macOS:
     ```
     ./gradlew build
     ```

3. **Find your compiled mod JAR** in:
   ```
   build/libs/
   ```
   The file will look like:
   ```
   yourmodid-version.jar
   ```

4. **To use or share your mod:**
   - Copy the JAR from `build/libs/` to the `mods` folder of any Forge 1.8.9 Minecraft installation.

> You do **not** need to include the `run` or `build` folders when sharing your mod—just the JAR in `build/libs/`.

 */


@Mod(modid = "stokbrot", name = "Stokbrot is King", version = "69.420")
public class main {

    public static List<PlayerState> recordedStates = new ArrayList<>();

    public static boolean is_gui = false;

    private boolean isRecording = false; // Tracks whether recording is active
    private boolean isPlaying = false; // Tracks whether recording is active
    private int index = 0; // Keeps track of the current view angle

    private KeyBinding recordKey; // Keybinding for starting/stopping recording
    private KeyBinding playKey; // Keybinding for starting/stopping recording

    private Minecraft mc;

    private static boolean toggled = false;

    public static double failsafe_trigger_distance = 3.0;
    public static int failsafe_backtrack = 4;


    private int smoothTicks = 0;
    private float startYaw, startPitch, endYaw, endPitch;
    private float[] yawNoise = new float[20];
    private float[] pitchNoise = new float[20];
    private boolean smoothing = false;

    private long playStartTime = 0;
    private float startYawNoise, endYawNoise, startPitchNoise, endPitchNoise;
    private int smoothingTicksTotal = 5; // Total ticks for smoothing

    private float noiseFactor = 5.0f; // Change this to control randomness

    private long lastMacroDuration = 0; // Store last duration for display

    public static class PlayerState {
        public double posX, posY, posZ;
        public float yaw, pitch;
        public int slot; // Add this line
        public boolean forward, left, right, backward, jump, sprint, sneak, attack, use;

        public PlayerState(double posX, double posY, double posZ,
                           float yaw, float pitch, int slot, // Add slot here
                           boolean forward, boolean left, boolean right, boolean backward, 
                           boolean jump, boolean sprint, boolean sneak,
                           boolean attack, boolean use) {
            this.posX = posX;
            this.posY = posY;
            this.posZ = posZ;
            this.yaw = yaw;
            this.pitch = pitch;
            this.slot = slot; // Add this line
            this.forward = forward;
            this.left = left;
            this.right = right;
            this.backward = backward;
            this.jump = jump;
            this.sprint = sprint;
            this.sneak = sneak;
            this.attack = attack;
            this.use = use;           
        }
    }


    public static void disconnect() {
        Minecraft mc = Minecraft.getMinecraft();
        
        if (mc.theWorld != null) {
            mc.theWorld.sendQuittingDisconnectingPacket(); // Send proper quit packet
            mc.loadWorld((WorldClient) null); // Unload the world
            mc.displayGuiScreen(new GuiMainMenu()); // Go to main menu
        }
    }

    private void unpressAllKeys() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
    }

    // Main.mc.gameSettings.keyBindLeft.getKeyCode(), left
    public static void writePlayerStatesToFile(String filePath) {
        File file = new File(filePath);
    
        // Check if the file exists, create it if it doesn't
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("File created: " + file.getAbsolutePath());
                }
            } catch (IOException e) {
                System.err.println("Error creating file: " + e.getMessage());
                return; // Stop execution if file creation fails
            }
        }
    
        // Now write to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) { // Overwrite file
            for (PlayerState state : recordedStates) {
                // Format: posX,posY,posZ,yaw,pitch,forward,left,right,backward,jump,sprint,sneak,attack,use
                writer.write(String.format("%.6f,%.6f,%.6f,%.2f,%.2f,%d,%b,%b,%b,%b,%b,%b,%b,%b,%b%n",
                        state.posX, state.posY, state.posZ,
                        state.yaw, state.pitch,
                        state.slot, // Save slot
                        state.forward, state.left, state.right, state.backward,
                        state.jump, state.sprint, state.sneak,
                        state.attack, state.use));
            }
            System.out.println("File written successfully.");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }


    }
    

    public static void loadPlayerStatesFromFile(String filePath) {
        recordedStates.clear(); // Clear existing data before loading
    
        File file = new File(filePath);
    
        // Check if the file exists, create it if it doesn't
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("File created: " + file.getAbsolutePath());
                }
            } catch (IOException e) {
                System.err.println("Error creating file: " + e.getMessage());
                return; // Stop execution if file creation fails
            }
        }
    
        // Now read the file
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(","); // Split by comma
                
                
                if (parts.length == 15) { // Now 15 fields
                    try {
                        // Parse position and angles
                        double x = Double.parseDouble(parts[0]);
                        double y = Double.parseDouble(parts[1]);
                        double z = Double.parseDouble(parts[2]);
                        float yaw = Float.parseFloat(parts[3]);
                        float pitch = Float.parseFloat(parts[4]);
                        int slot = Integer.parseInt(parts[5]); // Parse slot
                        boolean forward = Boolean.parseBoolean(parts[6]);
                        boolean left = Boolean.parseBoolean(parts[7]);
                        boolean right = Boolean.parseBoolean(parts[8]);
                        boolean backward = Boolean.parseBoolean(parts[9]);
                        boolean jump = Boolean.parseBoolean(parts[10]);
                        boolean sprint = Boolean.parseBoolean(parts[11]);
                        boolean sneak = Boolean.parseBoolean(parts[12]);
                        boolean attack = Boolean.parseBoolean(parts[13]);
                        boolean use = Boolean.parseBoolean(parts[14]);

                        recordedStates.add(new PlayerState(x, y, z, yaw, pitch, slot, forward, left, right, backward, jump, sprint, sneak, attack, use));
                    } 
                    catch (NumberFormatException e) {
                        System.err.println("Error parsing numbers in line: " + line);
                    }
                } 
                else {
                    System.err.println("Invalid line format: " + line); // Incorrect number of values
                }
            }
            System.out.println("File loaded successfully.");
        } 
        catch (IOException e){
            System.err.println("Error reading from file: " + e.getMessage());
        }
    }
    

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Register the keybinding (B key)
        recordKey = new KeyBinding("Start/Stop Recording", Keyboard.KEY_B, "!");
        playKey = new KeyBinding("Play Recording", Keyboard.KEY_P, "!");

        ClientRegistry.registerKeyBinding(recordKey);
        ClientRegistry.registerKeyBinding(playKey);


        // Register UI Class
        if (event.getSide().isClient()) {
            ClientCommandHandler.instance.registerCommand(new ini_UI());
        }
        System.out.println("[OpenUi] Registering command");

        // Register the event handler
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyPress(InputEvent.KeyInputEvent event) {
        // Check if the record key (B) is pressed

        if (playKey.isPressed()){          
            index = 0;

            if (recordedStates.isEmpty()) {
                mc.thePlayer.addChatMessage(new ChatComponentText("No recorded states found."));
                mc.thePlayer.addChatMessage(new ChatComponentText("Load one first! Or record one!"));
            } 
            else {
                boolean wasPlaying = isPlaying;
                isPlaying = !isPlaying;
                //mc.thePlayer.addChatMessage(new ChatComponentText("Playing: " + (isPlaying ? "\u00a7a Started" : "\u00a7c Stopped")));

                if (isPlaying && !wasPlaying) {
                    playStartTime = System.currentTimeMillis(); // Start time
                }
                /*
                if (!isPlaying && wasPlaying) {
                    long playEndTime = System.currentTimeMillis();
                    long duration = playEndTime - playStartTime;
                    long minutes = (duration / 1000) / 60;
                    long seconds = (duration / 1000) % 60;
                    mc.thePlayer.addChatMessage(new ChatComponentText(
                        "\u00a71R\u00a79a\u00a73n\u00a7b f\u00a7do\u00a75r\u00a7e " + minutes + "\u00a7a m\u00a7e " + seconds + "\u00a7r \u00a7as"
                    ));
                }
                 */
                
                if(!isPlaying){
                    unpressAllKeys();
                }
            }
        }

        if (recordKey.isPressed()) {
            // Toggle recording           
            if(isRecording){
                isRecording = false;            
                //writePlayerStatesToFile("mods/script.txt");
            }

            else{
                recordedStates.clear();
                isRecording = true;}

             
            //mc.thePlayer.addChatMessage(new ChatComponentText("Recording: " + (isRecording ? "\u00a7a Started" : "\u00a7c Stopped")));
            System.out.println("Recording: " + (isRecording ? "Started" : "Stopped"));
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {

        if (mc == null) {
            mc = Minecraft.getMinecraft();
        }

        if (is_gui) {
            mc.displayGuiScreen(new UI());
            is_gui = false;
        }

        // Check if it's the end of a tick (to avoid running twice per tick)
        if (event.phase == TickEvent.Phase.END) {

            // Check if player is valid
            EntityPlayerSP player = mc.thePlayer;
            if (player != null) {

                if(isPlaying && !isRecording){
                    if (index < recordedStates.size()) { // check if in index range to proceed

                        
                        PlayerState state = recordedStates.get(index);
                        
                            

                        double x = state.posX;
                        double y = state.posY;
                        double z = state.posZ;
                        double dx = player.posX;
                        double dy = player.posY;
                        double dz = player.posZ;



                        

                        //player.posY = state.posY;
                        //player.posZ = state.posZ;
                        
                        




                        player.rotationYaw = state.yaw;  // Set yaw (horizontal)
                        player.rotationPitch = state.pitch; // Set pitch (vertical)
                        mc.thePlayer.inventory.currentItem = state.slot; // Replay slot
                        
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), state.forward);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), state.left);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), state.right);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), state.backward);

                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), state.jump);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), state.sprint);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), state.sneak);

                        
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), state.attack);
                        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), state.use);
                            
                        
        

                        boolean safe = false;
                        for (int offset = -failsafe_backtrack; offset <= failsafe_backtrack; offset++) {
                            int checkIdx = index + offset;
                            if (checkIdx >= 0 && checkIdx < recordedStates.size()) {
                                PlayerState checkState = recordedStates.get(checkIdx);
                                double dxDiff = checkState.posX - player.posX;
                                double dyDiff = checkState.posY - player.posY;
                                double dzDiff = checkState.posZ - player.posZ;
                                double distance = Math.sqrt(dxDiff*dxDiff + dyDiff*dyDiff + dzDiff*dzDiff);
                                if (distance < failsafe_trigger_distance) {
                                    safe = true;
                                    break;
                                }
                            }
                        }
                        if (!safe) {
                            player.addChatMessage(new ChatComponentText("Failsafe Triggered at: " + LocalTime.now()));
                            unpressAllKeys();
                            isRecording = false;
                            isPlaying = false;
                            //disconnect(); // Disconnect from the server
                        }

                        index++; // Move to the next view angle


                    }
                    else{index = 0;}
                }


                if(isRecording && !isPlaying){
                     

                    
                    // Store Playerstate
                    recordedStates.add(new PlayerState(

                        player.posX,
                        player.posY,
                        player.posZ,

                        player.rotationYaw,
                        player.rotationPitch,

                        mc.thePlayer.inventory.currentItem, // Save slot

                        mc.gameSettings.keyBindForward.isKeyDown(),
                        mc.gameSettings.keyBindLeft.isKeyDown(),
                        mc.gameSettings.keyBindRight.isKeyDown(),
                        mc.gameSettings.keyBindBack.isKeyDown(),
                        mc.gameSettings.keyBindJump.isKeyDown(),
                        player.isSprinting(),
                        player.isSneaking(),
                        mc.gameSettings.keyBindAttack.isKeyDown(),
                        mc.gameSettings.keyBindUseItem.isKeyDown()
                    ));                                                                                                                   
                }
            }
        }

        if (UI.rdmChecked && isPlaying && index >= recordedStates.size() && recordedStates.size() > 1) {
            unpressAllKeys(); // Unpress all keys before smoothing
            // Prepare smoothing from last to first
            PlayerState last = recordedStates.get(recordedStates.size() - 1);
            PlayerState first = recordedStates.get(0);
            startYaw = last.yaw;
            startPitch = last.pitch;
            endYaw = first.yaw;
            endPitch = first.pitch;

            // Smoothing setup (when starting smoothing)
            startYawNoise = (float)((Math.random() - 0.5) * 2 * noiseFactor);
            endYawNoise = (float)((Math.random() - 0.5) * 2 * noiseFactor);
            startPitchNoise = (float)((Math.random() - 0.5) * 1 * noiseFactor);
            endPitchNoise = (float)((Math.random() - 0.5) * 1 * noiseFactor);

            smoothTicks = 0;
            smoothing = true;
            
            isPlaying = false; // Stop normal playback
        }

        if (smoothing && UI.rdmChecked && mc.thePlayer != null) {
            if (smoothTicks < smoothingTicksTotal) {
                float t = (float)smoothTicks / (smoothingTicksTotal - 1);
                float noiseYaw = startYawNoise + (endYawNoise - startYawNoise) * t;
                float noisePitch = startPitchNoise + (endPitchNoise - startPitchNoise) * t;
                float yaw = startYaw + (endYaw - startYaw) * t + noiseYaw;
                float pitch = startPitch + (endPitch - startPitch) * t + noisePitch;
                mc.thePlayer.rotationYaw = yaw;
                mc.thePlayer.rotationPitch = pitch;
                smoothTicks++;
            } else {
                smoothing = false;
                mc.thePlayer.rotationYaw = endYaw;
                mc.thePlayer.rotationPitch = endPitch;
                index = 0;
                isPlaying = true;
            }
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc == null) mc = Minecraft.getMinecraft();

        String displayText;
        if (isPlaying) {
            long now = System.currentTimeMillis();
            long duration = now - playStartTime;
            long minutes = (duration / 1000) / 60;
            long seconds = (duration / 1000) % 60;
            displayText = "\u00a71R\u00a79a\u00a73n\u00a7b f\u00a7do\u00a75r\u00a7e " + minutes + "\u00a7a m\u00a7e " + seconds + "\u00a7r \u00a7as";
            lastMacroDuration = duration;
        } else if (isRecording) {
            displayText = "\u00a7cRecording";
        } else if (lastMacroDuration > 0) {
            long minutes = (lastMacroDuration / 1000) / 60;
            long seconds = (lastMacroDuration / 1000) % 60;
            displayText = "\u00a77Idle \u00a7f| Last: \u00a71R\u00a79a\u00a73n\u00a7b f\u00a7do\u00a75r\u00a7e " + minutes + "\u00a7a m\u00a7e " + seconds + "\u00a7r \u00a7as";
        } else {
            displayText = "\u00a77Idle";
        }

        int x = movingOverlay ? org.lwjgl.input.Mouse.getX() / 2 : overlayX;
        int y = movingOverlay ? mc.displayHeight - org.lwjgl.input.Mouse.getY() / 2 : overlayY;
        mc.fontRendererObj.drawString(displayText, x, y, 0xFFFFFF, true);
    }

    public static int overlayX = 10;
    public static int overlayY = 10;
    public static boolean movingOverlay = false;
}